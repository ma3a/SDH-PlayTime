#!/usr/bin/env python
import contextlib as __stickytape_contextlib

@__stickytape_contextlib.contextmanager
def __stickytape_temporary_dir():
    import tempfile
    import shutil
    dir_path = tempfile.mkdtemp()
    try:
        yield dir_path
    finally:
        shutil.rmtree(dir_path)

with __stickytape_temporary_dir() as __stickytape_working_dir:
    def __stickytape_write_module(path, contents):
        import os, os.path

        def make_package(path):
            parts = path.split("/")
            partial_path = __stickytape_working_dir
            for part in parts:
                partial_path = os.path.join(partial_path, part)
                if not os.path.exists(partial_path):
                    os.mkdir(partial_path)
                    with open(os.path.join(partial_path, "__init__.py"), "wb") as f:
                        f.write(b"\n")

        make_package(os.path.dirname(path))

        full_path = os.path.join(__stickytape_working_dir, path)
        with open(full_path, "wb") as module_file:
            module_file.write(contents)

    import sys as __stickytape_sys
    __stickytape_sys.path.insert(0, __stickytape_working_dir)

    __stickytape_write_module('play_time_dao.py', b'import contextlib\nimport datetime\nimport sqlite3\nfrom typing import List, Tuple\n\n\nclass GameTimeDto:\n    def __init__(self, game_id: str, game_name: str, time: int):\n        self.game_id = game_id\n        self.game_name = game_name\n        self.time = time\n\n\nclass DailyGameTimeDto:\n    def __init__(self, date: str, game_id: str, game_name: str, time: int):\n        self.date = date\n        self.game_id = game_id\n        self.game_name = game_name\n        self.time = time\n\n\nclass PlayTimeDao:\n    _database_path: str\n\n    def __init__(self, database_path: str):\n        self._database_path = database_path\n        self._migrate()\n\n    def save_game_dict(self, game_id: str, game_name: str):\n        with self._in_transaction() as con:\n            con.execute(\n                """\n                INSERT INTO game_dict (game_id, name)\n                VALUES (:game_id, :game_name)\n                ON CONFLICT (game_id) DO UPDATE SET name = :game_name\n                WHERE name != :game_name\n                """,\n                {"game_id": game_id, "game_name": game_name}\n            )\n\n    def save_play_time(self, start: datetime.datetime, time_s: int, game_id: str):\n        with self._in_transaction() as con:\n            con.execute(\n                "INSERT INTO play_time(date_time, duration, game_id) VALUES (?,?,?)",\n                (start.isoformat(), time_s, game_id)\n            )\n\n    def append_overall_time(self, game_id: str, delta_time_s: int):\n        with self._in_transaction() as con:\n            con.execute(\n                """\n                INSERT INTO overall_time (game_id, duration)\n                VALUES (:game_id, :delta_time_s)\n                ON CONFLICT (game_id) DO UPDATE SET duration = duration + :delta_time_s\n                """,\n                {"game_id": game_id, "delta_time_s": delta_time_s}\n            )\n\n    def fetch_overall_playtime(self) -> List[GameTimeDto]:\n        with self._connection() as con:\n            con.row_factory = lambda c, row: GameTimeDto(\n                game_id=row[0], game_name=row[1], time=row[2])\n            return con.execute(\n                """\n                SELECT ot.game_id, gd.name AS game_name, ot.duration\n                FROM overall_time ot\n                        JOIN game_dict gd ON ot.game_id = gd.game_id\n                """\n            ).fetchall()\n\n    def fetch_per_day_time_report(self, begin: type[datetime.datetime], end: type[datetime.datetime]) -> List[DailyGameTimeDto]:\n        with self._connection() as con:\n            con.row_factory = lambda c, row: DailyGameTimeDto(\n                date=row[0], game_id=row[1], game_name=row[2], time=row[3])\n            return con.execute(\n                """\n                SELECT STRFTIME(\'%Y-%m-%d\', UNIXEPOCH(date_time), \'unixepoch\') AS date,\n                    pt.game_id                                                 AS game_id,\n                    gd.name                                                    AS game_name,\n                    SUM(duration)                                              AS time\n                FROM play_time pt\n                        LEFT JOIN game_dict gd ON pt.game_id = gd.game_id\n                WHERE UNIXEPOCH(date_time) BETWEEN UNIXEPOCH(:begin) AND \n                                                   UNIXEPOCH(:end)\n\n                GROUP BY STRFTIME(\'%Y-%m-%d\', UNIXEPOCH(date), \'unixepoch\'), pt.game_id, gd.name;\n                """,\n                {"begin": begin.isoformat(), "end": end.isoformat()}\n            ).fetchall()\n\n    def _current_migration_version(self):\n        with self._connection() as con:\n            con.execute(\n                "CREATE TABLE IF NOT EXISTS migration (id INT PRIMARY KEY);"\n            )\n            return con.execute(\n                "SELECT coalesce(max(id), 0) as max_id FROM migration"\n            ).fetchone()[0]\n\n    def _migrate(self):\n        version = self._current_migration_version()\n        self._migration(\n            version,\n            [\n                (1, [\n                    "CREATE TABLE play_time(date_time TEXT, duration INT, game_id TEXT)",\n                    "CREATE TABLE overall_time(game_id TEXT PRIMARY KEY, duration INT)",\n                    "CREATE TABLE game_dict(game_id TEXT PRIMARY KEY, name TEXT)",\n                ]),\n                (2, [\n                    "CREATE INDEX play_time_date_time_epoch_idx ON play_time(UNIXEPOCH(date_time));",\n                    "CREATE INDEX play_time_game_id_idx         ON play_time(game_id);",\n                    "CREATE INDEX overall_time_game_id_idx      ON overall_time(game_id);"\n                ])\n            ]\n        )\n\n    def _migration(self, existing_migration_id: int, migrations: List[Tuple[int, List[str]]]):\n        for migr in migrations:\n            if (migr[0] > existing_migration_id):\n                with self._in_transaction() as con:\n                    for stm in migr[1]:\n                        con.execute(stm)\n                    con.execute(\n                        "INSERT INTO migration (id) VALUES (?)", [migr[0]])\n\n    @contextlib.contextmanager\n    def _in_transaction(self):\n        with self._connection() as con:\n            yield con\n            con.commit()\n\n    def _connection(self):\n        return sqlite3.connect(self._database_path)\n')
    __stickytape_write_module('playtime.py', b'from datetime import timedelta\nfrom datetime import datetime, date, time, timedelta\nimport logging\nfrom typing import Dict, List\nfrom play_time_dao import DailyGameTimeDto, PlayTimeDao\nimport json\n\n\nDATE_FORMAT = "%Y-%m-%d"\nlogger = logging.getLogger()\n\n\nclass PlayTime:\n    dao: PlayTimeDao\n\n    def __init__(self, dao: PlayTimeDao) -> None:\n        self.dao = dao\n\n    def get_overall_time_statistics_games(self) -> Dict[str, int]:\n        data = self.dao.fetch_overall_playtime()\n        result = {}\n        for d in data:\n            result[d.game_id] = d.time\n        return result\n\n    def get_play_time_statistics(self, start: date, end: date):\n        start_time = datetime.combine(\n            start, time(00, 00, 00))\n        end_time = datetime.combine(\n            end, time(23, 59, 59, 999999))\n        data = self.dao.fetch_per_day_time_report(start_time, end_time)\n\n        data_as_dict: Dict[str, List[DailyGameTimeDto]] = {}\n        for d in data:\n            if d.date in data_as_dict:\n                data_as_dict[d.date].append(d)\n            else:\n                data_as_dict[d.date] = [d]\n\n        result = []\n        date_range = date_range_list(start, end)\n        for day in date_range:\n            date_str = day.strftime(DATE_FORMAT)\n            if (date_str in data_as_dict):\n                games = []\n                total_time = 0\n                for el in data_as_dict[date_str]:\n                    games.append({\n                        "gameId": el.game_id,\n                        "gameName": el.game_name,\n                        "time": el.time\n                    })\n                    total_time += el.time\n                result.append({\n                    "date": date_str,\n                    "games": games,\n                    "totalTime": total_time\n                })\n            else:\n                result.append({\n                    "date": date_str,\n                    "games": [],\n                    "totalTime": 0\n                })\n\n        return result\n\n    def get_all_play_time_statistics(self):\n        data = self.dao.fetch_overall_playtime()\n        games = []\n        total_time = 0\n        for g in data:\n            total_time += g.time\n            games.append({\n                "gameId": g.game_id,\n                "gameName": g.game_name,\n                "time": g.time\n            })\n        return [{\n            "date": "2999-01-01",\n            "games": games,\n            "totalTime": total_time\n\n        }]\n\n    def add_new_time(self, started_at: int, ended_at: int, game_id: str, game_name: str):\n        self.dao.save_game_dict(game_id, game_name)\n        day_end_for_start_at = timestamp_of_end_of_day(\n            datetime.fromtimestamp(started_at))\n        intervals = []\n        if (started_at < day_end_for_start_at and ended_at > day_end_for_start_at):\n            intervals.append(\n                (started_at, day_end_for_start_at + 1, game_id, game_name))\n            intervals.append(\n                (day_end_for_start_at + 1, ended_at, game_id, game_name))\n        else:\n            intervals.append(\n                (started_at, ended_at, game_id, game_name))\n\n        for interval in intervals:\n            (i_started_at, i_ended_at, i_game_id, i_game_name) = interval\n            length = i_ended_at - i_started_at\n            self.dao.save_play_time(datetime.fromtimestamp(\n                i_started_at), length, i_game_id)\n            self.dao.append_overall_time(i_game_id, length)\n\n    def migrate_from_old_storage(self, data: str):\n        data_dict = json.loads(data)["data"]\n        for date_str in data_dict:\n            date_time = datetime.combine(\n                datetime.strptime(date_str, DATE_FORMAT).date(), time(0, 0)\n            )\n            for game_id in data_dict[date_str]:\n                played_time = int(data_dict[date_str][game_id]["time"])\n                game_name = data_dict[date_str][game_id]["name"]\n                self.add_new_time(\n                    date_time.timestamp(),\n                    date_time.timestamp() + played_time,\n                    game_id,\n                    game_name\n                )\n\n\ndef timestamp_of_end_of_day(day_to_end):\n    result = datetime.combine(\n        day_to_end + timedelta(days=1), datetime.min.time()\n    )\n    return int(result.timestamp()) - 1\n\n\ndef date_range_list(start_date, end_date):\n    # Return list of datetime.date objects (inclusive) between start_date and end_date (inclusive).\n    date_list = []\n    curr_date = start_date\n    while curr_date <= end_date:\n        date_list.append(curr_date)\n        curr_date += timedelta(days=1)\n    return date_list\n')
    # autopep8: off
    import logging
    import os
    import sys
    from pathlib import Path
    
    from datetime import datetime
    from play_time_dao import PlayTimeDao
    from playtime import PlayTime, DATE_FORMAT
    
    log_dir = os.environ["DECKY_PLUGIN_LOG_DIR"]
    data_dir = os.environ["DECKY_PLUGIN_RUNTIME_DIR"]
    plugin_dir = Path(os.environ["DECKY_PLUGIN_DIR"])
    
    logging.basicConfig(filename=f"{log_dir}/decky-playtime.log",
                                            format='[Playtime] %(asctime)s %(levelname)s %(message)s',
                                            filemode='w+',
                                            force=True)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    
    # def add_plugin_to_path():
    #     directories = [["./"], ["python"]]
    #     for dir in directories:
    #         sys.path.append(str(plugin_dir.joinpath(*dir)))
    #
    #
    # add_plugin_to_path()
    
    
    
    class Plugin:
        playTime = None
    
        async def on_save_interval(self, started_at, ended_at, game_id, game_name):
            try:
                self.playTime.add_new_time(
                        started_at=started_at,
                        ended_at=ended_at,
                        game_id=game_id,
                        game_name=game_name
                )
            except Exception:
                logger.exception("Unhandled exception")
    
        async def get_play_time(self, start_date: str, end_date: str):
            logger.info(f"get_play_time start_date = '{start_date}' end_date = '{end_date}'")
            try:
                return self.playTime.get_play_time_statistics(
                        datetime.strptime(start_date, DATE_FORMAT).date(),
                        datetime.strptime(end_date, DATE_FORMAT).date(),
                )
            except Exception:
                logger.exception("Unhandled exception")
    
        async def get_all_play_time(self):
            logger.info(f"get_all_play_time")
            try:
                return self.playTime.get_all_play_time_statistics()
            except Exception:
                logger.exception("Unhandled exception")
    
        async def get_overall_times(self):
            logger.info(f"get_overall_time")
            try:
                return self.playTime.get_overall_time_statistics_games()
            except Exception:
                logger.exception("Unhandled exception")
    
        async def _main(self):
            try:
                dao = PlayTimeDao(f"{data_dir}/storage.db")
                self.playTime = PlayTime(dao)
    
                prev_storage_path = f"{data_dir}/detailed_storage.json"
                if os.path.exists(prev_storage_path):
                    old_data = open(prev_storage_path, "r").read()
                    self.playTime.migrate_from_old_storage(old_data)
                    os.rename(prev_storage_path, f"{prev_storage_path}.migrated")
    
            except Exception:
                logger.exception("Unhandled exception")
    
        async def _unload(self):
            logger.info("Unloading play time plugin")
            pass
    